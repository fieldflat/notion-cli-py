# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['notion_cli_py',
 'notion_cli_py.client',
 'notion_cli_py.configure',
 'notion_cli_py.operations',
 'notion_cli_py.utils']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.4.0,<0.5.0', 'requests>=2.27.1,<3.0.0', 'tabulate>=0.8.9,<0.9.0']

entry_points = \
{'console_scripts': ['notion-cli = notion_cli_py.cli:main']}

setup_kwargs = {
    'name': 'notion-cli-py',
    'version': '0.1.1',
    'description': 'NotionCLI - The CLI tool for Notion.co (https://www.notion.so/ja-jp/product).',
    'long_description': '## NotionCLI\n\nNotionCLI - The CLI tool for Notion.co (https://www.notion.so/ja-jp/product).\n\n## Installation\n\n* To install NotionCLI with pip, run: `pip install hogehoge`\n\n## How to use\n\n### Setup\n\nFirst, You need to create config file.\n\n## License\n\nLicensed under the MIT License.\n\n## Disclaimer\n\nThis is **NOT** an official Notion product.\n',
    'author': 'Tomonori HIRATA',
    'author_email': 'tomonori4565@icloud.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/fieldflat',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
