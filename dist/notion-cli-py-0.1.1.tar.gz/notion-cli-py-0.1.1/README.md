## NotionCLI

NotionCLI - The CLI tool for Notion.co (https://www.notion.so/ja-jp/product).

## Installation

* To install NotionCLI with pip, run: `pip install hogehoge`

## How to use

### Setup

First, You need to create config file.

## License

Licensed under the MIT License.

## Disclaimer

This is **NOT** an official Notion product.
